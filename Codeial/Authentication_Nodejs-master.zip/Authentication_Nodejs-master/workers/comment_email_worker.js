//import the kue module
const queue = require('../config/kue');
//import the commentsMailer
const commentsMailer = require('../mailers/comments_mailer');

//jobs are processed in the queue by the worker
queue.process('emails', function(job, done){

    console.log('emails worker is processing a job ', job.data);

    commentsMailer.newComment(job.data); //calling the particular mailer based on priority 

    done();

});