//Load the nodemailer
const nodeMailer = require('../config/nodemailer');


// this is another way of exporting a method..
exports.newComment = (comment) => {

    //console.log('inside newComment mailer', comment);
     
    //here we are sending the (html or ejs  template)  through path
    let htmlString = nodeMailer.renderTemplate({comment: comment}, '/comments/new_comment.ejs');


    //sendMail will send the mail..
    nodeMailer.transporter.sendMail({
       from: 'vishnunimmala786gmail.com',
       to: comment.user.email, //user who published the comment will get a notification via mail 
       subject: "New Comment Published!",
      // html: '<h1>Yup, your comment is now published!</h1>' //body of the  rendered mail 
       html: htmlString 

    }, (err, info) => {
        if (err){
            console.log('Error in sending mail', err);
            return;
        }
        //console.log('Message sent', info);
        return;
    });
}