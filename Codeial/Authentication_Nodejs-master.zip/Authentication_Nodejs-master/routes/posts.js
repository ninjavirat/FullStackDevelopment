const express = require('express');
const router = express.Router();
//uses passport for authentication
const passport = require('passport');

//we need to import the controller to get the action.now we are able to access the actions in the controller
const postsController = require('../controllers/posts_controller');

//router handling the controller for the action.and using passport for authentication(checkAuthentication).
router.post('/create',passport.checkAuthentication, postsController.create);

//router for handling the postsController for the action(delete the post).and using the passport for authentication.
router.get('/destroy/:id', passport.checkAuthentication, postsController.destroy);



module.exports = router;