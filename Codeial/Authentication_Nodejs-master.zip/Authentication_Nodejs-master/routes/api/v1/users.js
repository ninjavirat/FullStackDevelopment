/////////////////////////////
const express = require('express');
const router = express.Router();
/////////////////////////////

//handling the 'users_api'(Controller)  for executing the actions
const usersApi = require('../../../controllers/api/v1/users_api');

//calling the action on post request
router.post('/create-session', usersApi.createSession);

///////////////////////
module.exports = router;
//////////////////////