const express=require('express');
const router =express.Router();

//handles the posts router
router.use('/posts', require('./posts'));

//referring to the users router
router.use('/users', require('./users'));


module.exports = router;