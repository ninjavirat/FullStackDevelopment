////////////////////////////
const express=require('express');
const router =express.Router();
////////////////////////////

//import the passport library for autherization check..
const passport = require('passport');

//acess the controller for executing the action..
const postsApi = require("../../../controllers/api/v1/posts_api");


//calling the action by controller.
router.get('/', postsApi.index);


//used for deleting the post
// router.delete('/:id', postsApi.destroy);


//used for deleting the post by using the  jwt autherization check
router.delete('/:id', passport.authenticate('jwt', {session: false}), postsApi.destroy);


////////////////////////
module.exports = router;
////////////////////////