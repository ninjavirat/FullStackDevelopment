//////////////////////Setting up the Express Server////////////////////////////
const express = require('express');
const router = express.Router();
//////////////////////////////////////////////////////////////////////////////


//import the likesController module..
const likesController = require('../controllers/likes_controller');

//router request in the url for which invoking the specific controller action..
router.post('/toggle', likesController.toggleLike);


module.exports = router;