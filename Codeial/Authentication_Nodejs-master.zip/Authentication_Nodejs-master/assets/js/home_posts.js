{   
    // method to submit the form data of the new post using AJAX
    let createPost = function(){
        let newPostForm = $('#new-post-form');//id of the post form

        newPostForm.submit(function(e){
            e.preventDefault();//it will obstructs the submission through action of the form and make it manual through AJAX..

            $.ajax({
                type: 'post', //action :POST
                url: '/posts/create',//url of the post form 
                data: newPostForm.serialize(),//data will be converted into JSON format where data(content) will be the key and value will be the value of the form..
                success: function(data){
                //    console.log(data);

                   let newPost = newPostDom(data.data.post); //called the DOM function.apply,by inspecting  we can see data.data in the console.
                   $('#posts-list-container>ul').prepend(newPost);// append the posts which are reccently posted comes first..

                   deletePost($(' .delete-post-button', newPost));//calling the delete post function,where it will deletes the post dynamically..

                    // call the create comment class
                    new PostComments(data.data.post._id);

                     //enable the functionality of the toggle like button on the new post
                     new ToggleLike($(' .toggle-like-button', newPost));

                    new Noty({
                        theme: 'relax',
                        text: "Post published!",
                        type: 'success',
                        layout: 'topRight',
                        timeout: 1500
                        
                    }).show();

                
                }, error: function(error){
                    console.log(error.responseText);
                }
            });
        });
    }

  // createPost(); //call the creatPost function 

 // method to create a post in DOM
 let newPostDom = function(post){
    // CHANGE :: show the count of zero likes on this post
    return $(`<li id="post-${post._id}">
                <p>
                    
                    <small>
                        <a class="delete-post-button"  href="/posts/destroy/${ post._id }">X</a>
                    </small>
                   
                    ${ post.content }
                    <br>
                    <small>
                    ${ post.user.name }
                    </small>

                   
                    <br>
                        <small>
                                 
                                <a class="toggle-like-button" data-likes="0" href="/likes/toggle/?id=${post._id}&type=Post">
                                    0 Likes
                                </a>
                            
                        </small>
                    

                </p>
                <div class="post-comments">
                    
                        <form action="/comments/create" method="POST">
                            <input type="text" name="content" placeholder="Type Here to add comment..." required>
                            <input type="hidden" name="post" value="${ post._id }" >
                            <input type="submit" value="Add Comment">
                        </form>
           
            
                    <div class="post-comments-list">
                        <ul id="post-comments-${ post._id }">
                            
                        </ul>
                    </div>
                </div>
                
            </li>`)
    }  



    // method to delete a post from DOM.blocking the normal behaviour of the deleting the post and doing the same task dynamically through the AJAX.
    let deletePost = function(deleteLink){
        $(deleteLink).click(function(e){
            e.preventDefault();

            $.ajax({
                type: 'get',
                url: $(deleteLink).prop('href'), //getting href links here
                success: function(data){
                    $(`#post-${data.data.post_id}`).remove(); //Deleting the post.. populating it by calling the   "deletePost($(' .delete-post-button', newPost))"

                    new Noty({
                        theme: 'relax',
                        text: "Post Deleted",
                        type: 'success',
                        layout: 'topRight',
                        timeout: 1500
                    }).show();
                },error: function(error){
                    console.log(error.responseText);
                }
            });

        });
    }

      // loop over all the existing posts on the page (when the window loads for the first time) and call the delete post method on delete link of each, also add AJAX (using the class we've created) to the delete button of each
      let convertPostsToAjax = function(){
        $('#posts-list-container>ul>li').each(function(){
            let self = $(this);
            let deleteButton = $(' .delete-post-button', self);
            deletePost(deleteButton);

            // get the post's id by splitting the id attribute
            let postId = self.prop('id').split("-")[1]
            new PostComments(postId);
        });
    }



    createPost();

    convertPostsToAjax();

 }


