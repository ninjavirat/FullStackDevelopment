//import the kue
const kue = require('kue');
//create the queue 
const queue = kue.createQueue();
//export the queue
module.exports = queue;