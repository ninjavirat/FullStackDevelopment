//created the middleware for accessing the flash messages through req and sending through the res.
module.exports.setFlash = function(req, res, next){
    res.locals.flash = {
        //we are accessing the flash Meassages through req.flash and sending through res.locals.flash by setFlash to the ejs or Template(eg:layout.ejs).
        'success': req.flash('success'),
        'error': req.flash('error')
    }
    next();//Calling the next req or res 
}