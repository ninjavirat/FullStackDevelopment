//import the passport library
const passport = require('passport');
//import the passport-jwt for Strategy
const JWTStrategy = require('passport-jwt').Strategy;
const ExtractJWT = require('passport-jwt').ExtractJwt;

//requires the user data for authentication of JWT
const User = require('../models/user');

//created in Header of the JWT by encrypting..
let opts = {
    jwtFromRequest: ExtractJWT.fromAuthHeaderAsBearerToken(),
    secretOrKey: 'codeial'
}


//created the JWTstrategy  for payload creation which stores the info of the user if user is found..
passport.use(new JWTStrategy(opts, function(jwtPayLoad, done){

    User.findById(jwtPayLoad._id, function(err, user){
        if (err){console.log('Error in finding user from JWT'); return;}

        if (user){
            return done(null, user);
        }else{
            return done(null, false);
        }
    })

}));

/////////////////////////
module.exports = passport;
/////////////////////////
