//process the Obeserver for implementing Socket.io connection
module.exports.chatSockets = function(socketServer){
    let io = require('socket.io')(socketServer);
    //requesting for connection..
    io.sockets.on('connection', function(socket){
        console.log('new connection received', socket.id);

        socket.on('disconnect', function(){
            console.log('socket disconnected!');
        });

        
        socket.on('join_room', function(data){
            console.log('joining request rec.', data);

            socket.join(data.chatroom);

            io.in(data.chatroom).emit('user_joined', data);
        });

        // (2)detect send_message and broadcast to everyone in the room from Observer(Server) side..
        socket.on('send_message', function(data){
            io.in(data.chatroom).emit('receive_message', data);// (3)followed by emit('recieve_messge) from Observer to all Subscribers..
        });

    });

}