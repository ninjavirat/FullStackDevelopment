//import the required libraries 
const nodemailer = require("nodemailer");
const ejs = require('ejs');//useful for rendering pages 
const path = require('path')
///////////////////////////////



//lets define the transporter which is essential as it plays major role in sending the mail..
let transporter = nodemailer.createTransport({
    service: 'gmail',
    host: 'smtp.gmail.com',
    port: 587,//SMTP over SSL/TLS works over port
    secure: false,
    //Authentication Object in transporter
    auth: {
        user: 'vishnunimmala786',//mailID
        pass: 'GetForce77299@'   //Password
    }
});



//lets define the renderTemplate which contain the info the location where ejs template files will store and data inside the template..
let renderTemplate = (data, relativePath) => {
    let mailHTML;
    ejs.renderFile(
        path.join(__dirname, '../views/mailers', relativePath),
        data,
        function(err, template){
         if (err){console.log('error in rendering template',err); return}
         
         mailHTML = template;
        }
    )

    return mailHTML;
}


//here we need to export the transporter and renderTemplate
module.exports = {
    transporter: transporter,
    renderTemplate: renderTemplate
}