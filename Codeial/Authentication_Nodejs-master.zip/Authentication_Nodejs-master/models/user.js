const mongoose=require('mongoose');

//imported the multer
 const multer = require('multer');
 //imported the path library
 const path = require('path');
 //path(where files will be stored) for storing the files which will converted into string by path function..
 const AVATAR_PATH = path.join('/uploads/users/avatars');

//Creating the user Schema
const userSchema=new mongoose.Schema({
      email:{
          type:String,
          required:true,
          unique:true
          
      },

      password: {
        type:String,
        required:true,
        
    },

    name:{
        type:String,
        required:true,
        
    },
    //Declared the avatar schema for uploading the files through form by using the multer library..it will store the path of the file 
    avatar: {
        type:String
    },
    /////////

    //referencing to the friendship Schema..
    friendships: [
      { 
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Friendship' 
      }
  ]

},{
    timestamps:true
});


//The disk storage engine gives you full control on storing files to disk.
let storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // it is the path of the file models, and taking to the '/uploads/users/avatars' Path for file storage..
    cb(null, path.join(__dirname,'..',AVATAR_PATH));
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now()); //avatar file store with date 
  }
})


//static methods to make it available in the other files
userSchema.statics.uploadedAvatar = multer({storage: storage}).single('avatar');
userSchema.statics.avatarPath = AVATAR_PATH;
////////////////

const User = mongoose.model('User',userSchema);

module.exports=User;