//comments_controller for handling the comments which are submitted by the form  itself.
const Comment = require('../models/comment');
const Post = require('../models/post');
////////////////////////////////////////////

//Load the comments_mailer module..
const commentsMailer = require('../mailers/comments_mailer');


////////////////////////////////////////////////////////////////////
//import the kue 
const queue = require('../config/kue');
//import the comment_email_worker
const commentEmailWorker = require('../workers/comment_email_worker');
////////////////////////////////////////////////////////////////////

//import the like module
const Like = require('../models/like');


////////////////////////////////////////////////////////////////////////////////////////////////////////////
//here  we are try to find the post.if it  post exists then only we are creating the comments to that post.
// module.exports.create = function(req, res){
//     Post.findById(req.body.post, function(err, post){

//         if (post){
//             Comment.create({
//                 content: req.body.content,
//                 post: req.body.post,
//                 user: req.user._id
//             }, function(err, comment){
//                 // handle error
//                 post.comments.push(comment);//we are puushing the comments into that post
//                 post.save();//we are updating the post
//                 res.redirect('/');
//             });
//         }

//     });
// }
////////////////////////////////////////////////////////////////////////////////////////////////////////////


//used Async Await Mechanism for creating the comment.everything is same,before it was many callbacks and nested so i just removed the call back function and exected separately but to make it clean and smart enough to understand.
module.exports.create = async function(req, res){

    try{
        let post = await Post.findById(req.body.post);

        if (post){
            let comment = await Comment.create({
                content: req.body.content,
                post: req.body.post,
                user: req.user._id
            });

            post.comments.push(comment);
            post.save();


            // Similar for comments to fetch the user's id!
            comment = await comment.populate('user', 'name email').execPopulate();
            //commentsMailer.newComment(comment);//calling the newComment() method..
            //////////////////////////////////

            
            //queue for specific process(like notifications,OTP,emails etc) is created by the worker 
            let job = queue.create('emails', comment).save(function(err){
                if (err){
                    console.log('Error in sending to the queue', err);
                    return;
                }
                console.log('job enqueued', job.id);

            })
            ////////////////////////////////////////////////////////////////////////////////////////



            if (req.xhr){
              
    
                return res.status(200).json({
                    data: {
                        comment: comment
                    },
                    message: "Post created!"
                });
            }

            req.flash('success', 'Comment published!');//flash message

            res.redirect('/');
        }
    }catch(err){
        // console.log('Error', err);
        // return;

        req.flash('error', err);//flash Message
        return;

    }
    
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Deleting the Comment of the user."params.id" converts into string and also check if the Comment exists..
// module.exports.destroy = function(req, res){
//     Comment.findById(req.params.id, function(err, comment){
//         // .id means converting the object id into string.Here we are matching the user of the Comment and requested user are same(matches)..
//         if (comment.user == req.user.id){
//             //before deleting the post we need to store the id of the post for which comment to be deleted.
//             //If we won't store the id of the post then post will be deleted, that we do not want to happen.
//             let postId = comment.post;
//             //reomve the comment
//             comment.remove();
//             //Now we are finding the id post from the all posts,and pulling the comments id's from the list of the comment ids which has been deleted..
//             Post.findByIdAndUpdate(postId, { $pull: {comments: req.params.id}}, function(err, post){
//                 return res.redirect('back');
//             })
//         }else{
//             return res.redirect('back');
//         }
//     });
// }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// used Async Await mechanism for Deleting the comment of the user
module.exports.destroy = async function(req, res){

    try{
        let comment = await Comment.findById(req.params.id);

        if (comment.user == req.user.id){

            let postId = comment.post;

            comment.remove();

            let post = Post.findByIdAndUpdate(postId, { $pull: {comments: req.params.id}});


             //destroy the associated likes for this comment
             await Like.deleteMany({likeable: comment._id, onModel: 'Comment'});


             // send the comment id which was deleted back to the views
             if (req.xhr){
                return res.status(200).json({
                    data: {
                        comment_id: req.params.id
                    },
                    message: "Post deleted"
                });
            }
            ///////////////////////////DYNAMIC/////////////////////////////


            req.flash('success', 'Comment deleted!');//flash Message.

            return res.redirect('back');
        }else{
            req.flash('error', 'Unauthorized');//flash Message
            return res.redirect('back');
        }
    }catch(err){
        // console.log('Error', err);
        req.flash('error', err);//flash Message
        return;
    }
    
}