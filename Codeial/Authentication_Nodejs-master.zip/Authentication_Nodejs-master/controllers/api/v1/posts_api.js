
//import the '../../../models/post' as we need to fetch the all the posts..
const Post = require('../../../models/post');

//import the comment 
const Comment = require('../../../models/comment');


//created the controller action and returning the JSON
/////////////////////////////////////////////////////
// module.exports.index = function(req,res){
//        return res.json(200, {
//               message: "List of posts",
//               posts: []
//        })
// }
////////////////////////////////////////////////////


//created the controller action for fetching the posts and returning the JSON and adding the async await action mechanism,we taken the posts field from home controller..
module.exports.index = async function(req, res){

       let posts = await Post.find({})
           .sort('-createdAt')
           .populate('user')
           .populate({
               path: 'comments',
               populate: {
                   path: 'user'
               }
           });
   
       return res.json(200, {
           message: "List of posts",
           posts: posts //fetching the posts from database itself..
       })
   }



//Deleting the post via api{ run iin the POSTMAN},native Application..
module.exports.destroy = async function(req, res){

       try{
           let post = await Post.findById(req.params.id); //finding the post..
   
           if (post.user == req.user.id){
               post.remove(); //removing the post
   
               await Comment.deleteMany({post: req.params.id}); //deleting the comments in the post..
   
   
              //return the JSON on  success
               return res.json(200, {
                   message: "Post and associated comments deleted successfully!"
               });
           }else{
              //  req.flash('error', 'You cannot delete this post!');
              //  return res.redirect('back');

              return res.json(401, {
                     message: "You cannot delete this post!"
                 });
     
           }
   
       }catch(err){
           console.log('********', err);
           return res.json(500, {
               message: "Internal Server Error"
           });
       }
       
   }
   