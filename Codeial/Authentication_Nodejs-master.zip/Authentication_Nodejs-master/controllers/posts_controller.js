//used for getting the post schema
const Post = require('../models/post')
//used for deleting the comments of the post,so we need to define it
const Comment = require('../models/comment');

//import the like module
const Like = require('../models/like');

//creating the post 
/////////////////////////////////////////////////////////////////
// module.exports.create = function(req, res){
//     Post.create({
//         content: req.body.content,//storing the content 
//         user: req.user._id  //we just need the id as it is unique.
//     }, function(err, post){
//         if(err){console.log('error in creating a post'); return;}

//         return res.redirect('back');
//     });
// }
////////////////////////////////////////////////////////////////

//used Async Await Mechanism for creating the post.everything is same,before it was many callbacks and nested so i just removed the call back function and exected separately but to make it clean and smart enough to understand.
module.exports.create = async function(req, res){
    try{

        let post = await Post.create({
            content: req.body.content,
            user: req.user._id
        });

        // ajax request is in (xml http request) for creating the post,response is in the JSON format.. 
        if (req.xhr){
               // if we want to populate just the name of the user (we'll not want to send the password in the API), this is how we do it!
            post = await post.populate('user', 'name').execPopulate();
            
            return res.status(200).json({
                data: {
                    post: post //sending the data of the post
                },
                message: "Post created!" //message
            });
        }

         
        req.flash('success', 'Post published!'); //flash Message
        return res.redirect('back');

    }catch(err){
        // console.log('Error', err);
        // return;

        req.flash('Error', err);//flash Message
        console.log(err);
        return res.redirect('back');

    }
  
}



////////////////////////////////////////////////////////////////////////////////////////////////////

//Deleting the post of the user."params.id" converts into string and also check if the post exists..
// module.exports.destroy = function(req, res){
//     Post.findById(req.params.id, function(err, post){
//         // .id means converting the object id into string.Here we are matching the user of the post and requested user are same..
//         if (post.user == req.user.id){
//             post.remove();//remove the post
//             //delete  all the comments of that particular post 
//             Comment.deleteMany({post: req.params.id}, function(err){
//                 return res.redirect('back');
//             });
//         }else{
//             return res.redirect('back');
//         }

//     });
// }
///////////////////////////////////////////////////////////////////////////////////////////////////////


// used Async Await mechanism for Deleting the post of the user
module.exports.destroy = async function(req, res){

    try{
        let post = await Post.findById(req.params.id);

        if (post.user == req.user.id){

            //delete the associated likes for the post and all its comments' likes too
            await Like.deleteMany({likeable: post, onModel: 'Post'});
            await Like.deleteMany({_id: {$in: post.comments}});
            //////////////////////////////////////////////////////////////////////////


            post.remove();

            await Comment.deleteMany({post: req.params.id});
            
            // ajax request is in (xml http request) for deleting the post,response is in the JSON format.. 
            if (req.xhr){
                return res.status(200).json({
                    data: {
                        post: post
                    },
                    message: "Post created!"
                });
            }
    

            req.flash('success', 'Post and associated comments deleted!'); //flash Message
            return res.redirect('back');
        }else{
            req.flash('error', 'You cannot delete this post!'); //flash message
            return res.redirect('back');
        }

    }catch(err){
        // console.log('Error', err);
        // return;

        req.flash('error', err); //flash message.
        return res.redirect('back');
    }
    
}
