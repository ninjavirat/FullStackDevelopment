const Post = require('../models/post');
//import user because we need to access all the users to the home page
const User = require('../models/user');

//server side
// module.exports.home = function(req, res){
    //request
    // console.log(req.cookies);
    //response
    // res.cookie('user_id', 25);

    // Post.find({}, function(err, posts){
    //     return res.render('home', {
    //         title: "Codeial | Home",
    //         posts:  posts
    //     });
    // });

    // populate the user of each post
    // Post.find({}).populate('user').exec(function(err, posts){
    //     return res.render('home', {
    //         title: "Home",
    //         posts:  posts
    //     });
    // })
     


    // populate the user of each post along with the comment and user of that comment..
//     Post.find({})
//     .populate('user')
//     .populate({
//         path: 'comments',
//         populate: {
//             path: 'user'
//         }
//     })
//     .exec(function(err, posts){
//         //locate the user,we are fetching all the users.
//         User.find({}, function(err, users){
//             return res.render('home', {
//                 title: "Codeial | Home",
//                 posts:  posts,
//                 //we are fetching all the users to the home page
//                 all_users: users
//             });
//         });
       
//     })

// }

// module.exports.actionName = function(req, res){}



//Using The Async Await mechanism here
module.exports.home = async function(req, res){

    try{
         // populate the user of each post,on Success it will return to the let posts
        let posts = await Post.find({})

        .sort('-createdAt')//nearest post will be the post which has created recently..

        .populate('user')
        .populate({
            path: 'comments',
            populate: {
                path: 'user'
            },
        //populates the likes of each comment
            populate: {
                path: 'likes'
            }
        }).populate('likes');//populates the likes of each post
    
        let users = await User.find({});

        return res.render('home', {
            title: "Codeial | Home",
            posts:  posts,
            all_users: users
        });

    }catch(err){
        console.log('Error', err);
        return;
    }
   
}




// module.exports.actionName = function(req, res){}


// using then
// Post.find({}).populate('comments').then(function());

// let posts = Post.find({}).populate('comments').exec();

// posts.then()

