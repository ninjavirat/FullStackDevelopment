 const mongoose=require('mongoose');
 //conection to the Robo3T.
// mongoose.connect('mongodb://localhost/codeial_development');
//I used the cloud mongoDB atlas for the Db.
const uri = "mongodb+srv://nimmala:vishnu77299@cluster0-aytjs.mongodb.net/test?retryWrites=true&w=majority";
mongoose.connect(uri,{   useNewUrlParser: true,
    useUnifiedTopology: true
});

const db=mongoose.connection;
db.on('error',console.error.bind(console,'Error connecting to MongoDB'));
db.once('open',function(){
    console.log("Connected to Database:: MongoDB");
});
 module.exports=db;

