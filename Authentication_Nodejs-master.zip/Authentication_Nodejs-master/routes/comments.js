//comments router for handling the actions in the comments router.
const express = require('express');
const router = express.Router();
const passport = require('passport');

const commentsController = require('../controllers/comments_controller');

router.post('/create', passport.checkAuthentication, commentsController.create);


//router for handling the commentsController for the action(delete the comment).and using the passport for authentication of the user.
router.get('/destroy/:id', passport.checkAuthentication, commentsController.destroy);

module.exports = router;