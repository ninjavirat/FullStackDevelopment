const express = require('express');
const router = express.Router();
//passport library
const passport=require('passport');

const usersController = require('../controllers/users_controller');

// router.get('/profile', passport.checkAuthentication, usersController.profile);
//acess the profile page to the authenticated user,change the '/profile' to '/profile/:id' as the route change at the home.ejs then check at the usersController.profile
router.get('/profile/:id', passport.checkAuthentication, usersController.profile);
//Router for updating the profile of the User..
router.post('/update/:id', passport.checkAuthentication, usersController.update);



//router for the controller1 
router.get('/sign-Up',usersController.signUp);
router.get('/sign-In',usersController.signIn);

//router for the controller2 (Note:not "get" because we are posting the form)
// router.get('/create',usersController.create);
router.post('/create',usersController.create);


//use passport as a middleware to authenticate
router.post('/create-session',passport.authenticate(
    'local',
    {failureRedirect: '/users/sign-In'},
),usersController.createSession);


//on clicking sign-out it is calling the destroySession function to destroy the session
router.get('/sign-out',usersController.destroySession);

module.exports = router;









 