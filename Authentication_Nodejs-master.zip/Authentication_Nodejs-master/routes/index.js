const express=require('express');
const router =express.Router();
console.log('router loaded');
const homeController=require('../controllers/home_controller');
router.get('/',homeController.home);
router.use('/users',require('./users'));
//uses the posts router -------in form "/posts/create".it is just referrring the neighbour router
router.use('/posts', require('./posts'));
//uses the comments router -------in form "/comments/create".it is just referrring the neighbour router
router.use('/comments', require('./comments'));

//for any further routes ,access from here
//router.use('/routerName',require('./routerfile));
module.exports=router;