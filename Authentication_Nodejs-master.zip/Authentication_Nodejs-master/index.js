const express = require('express');
//cookie Parser
const cookieParser = require('cookie-parser');
const app = express();
const port = 7000;
//use the express layout library
const expressLayouts=require('express-ejs-layouts');
//mongoose connection
const db =require('./config/mongoose');


//used for the session cookie
const session = require('express-session');
const passport=require('passport');
const passportLocal=require('./config/passport-local-strategy');

//used Mongo store for session Cookies
const MongoStore = require('connect-mongo')(session);

//used sassMiddleware 
const sassMiddleware = require('node-sass-middleware')

//app to use sassMiddleware so that files will be pre compiled early can be easily translated to css while browser is running .delete-button
app.use(sassMiddleware({
     src:'./assets/scss',
     dest:'./assets/css',
     debug:true,
     outputStyle:'expanded',
     prefix:'/css'//here it will look into the files where css files is located but it uses scss folder for use.

}));

//cookie parser
app.use(express.urlencoded());
app.use(cookieParser());


//use the static files access
app.use(express.static('./assets'));

app.use(expressLayouts);


//extract style and scripts from sub pages into the layout
app.set('layout extractStyles',true);
app.set('layout extractScripts',true);


//set up the view engine
app.set('view engine','ejs');
app.set('views','./views');


//creating the cookie
//mongo "store" is used to store the session cookie in the db
app.use(session({
        name:'codial',
        //TODO change the secret before deployment in production mode
        secret:'blahsomething',
        saveUninitialized:false,
        resave:false,
        cookie:{
            maxAge:(1000 * 60* 100)
        },
        store: new MongoStore(
            {
                mongooseConnection: db,
                autoRemove: 'disabled'
            
            },
            function(err){
                console.log(err ||  'connect-mongodb setup ok');
            }
        )
    }));
    

//helps for session
app.use(passport.initialize());
app.use(passport.session());

//app to use passport authenticator and calling the setAuthennticatedUser function as middleware
app.use(passport.setAuthenticatedUser);

//use express router 
app.use('/',require('./routes'));


app.listen(port, function(err){
    if (err){
        console.log(`Error in running the server: ${err}`);
    }
    console.log(`Server is running on port: ${port}`);
});

