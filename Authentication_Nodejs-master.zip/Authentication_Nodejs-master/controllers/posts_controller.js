//used for getting the post schema
const Post = require('../models/post')
//used for deleting the comments of the post,so we need to define it
const Comment = require('../models/comment');
//creating the post 
module.exports.create = function(req, res){
    Post.create({
        content: req.body.content,//storing the content 
        user: req.user._id  //we just need the id as it is unique.
    }, function(err, post){
        if(err){console.log('error in creating a post'); return;}

        return res.redirect('back');
    });
}


//Deleting the post of the user."params.id" converts into string and also check if the post exists..
module.exports.destroy = function(req, res){
    Post.findById(req.params.id, function(err, post){
        // .id means converting the object id into string.Here we are matching the user of the post and requested user are same..
        if (post.user == req.user.id){
            post.remove();//remove the post
            //delete  all the comments of that particular post 
            Comment.deleteMany({post: req.params.id}, function(err){
                return res.redirect('back');
            });
        }else{
            return res.redirect('back');
        }

    });
}

