const Post = require('../models/post');
//import user because we need to access all the users to the home page
const User = require('../models/user');
//server side
module.exports.home = function(req, res){
    //request
    // console.log(req.cookies);
    //response
    // res.cookie('user_id', 25);

    // Post.find({}, function(err, posts){
    //     return res.render('home', {
    //         title: "Codeial | Home",
    //         posts:  posts
    //     });
    // });

    // populate the user of each post
    // Post.find({}).populate('user').exec(function(err, posts){
    //     return res.render('home', {
    //         title: "Home",
    //         posts:  posts
    //     });
    // })
     


    // populate the user of each post along with the comment and user of that comment..
    Post.find({})
    .populate('user')
    .populate({
        path: 'comments',
        populate: {
            path: 'user'
        }
    })
    .exec(function(err, posts){
        //locate the user,we are fetching all the users.
        User.find({}, function(err, users){
            return res.render('home', {
                title: "Codeial | Home",
                posts:  posts,
                //we are fetching all the users to the home page
                all_users: users
            });
        });
       
    })

}

// module.exports.actionName = function(req, res){}
