var a =10;
console.log(a,b,c);
if(a<=10){
   var b=40;
}else {
    var c=30;
}